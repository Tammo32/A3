
#include "Node.h"

Node::Node(Patient* tile, Node* next)
{
   // TODO 
}

Node::Node(Node& other)
{
   // TODO
}
